# TreasureSpotter ProGuard Rules

# Keep WebView JavaScript interface
-keepclassmembers class com.treasurespotter.app.MainActivity$AndroidBridge {
    public *;
}

# Keep all public classes
-keep public class * extends android.app.Activity
-keep public class * extends android.webkit.WebViewClient
-keep public class * extends android.webkit.WebChromeClient

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**
